
# Steps
1. Activite/inactive (classification)

2. Quantitative activity prediction (regression)

3. Feature importance (classification)

4. Feature importance (regression)