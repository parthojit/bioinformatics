# Overview
Protherm is a database which consists of thousands of protein mutants’thermostability data.


# Methods
Supervised Learning -  SVM, RF, ANN, NBC, KNN

Regression - SVR, KNN Reg, MLP Reg, RF Reg

# Steps
1. Evaluate ddG and dTm binary classification for 6 models and evaluate CV accuracy, Test accuracy and Test AUC.

2. Evaluate ddG and dTm ternary classification for 6 models and evaluate CV accuracy, Test accuracy and Test AUC.

3. Evaluate ddG regression.

4. Evaluate dTm regression. 

5. Feature Selection *